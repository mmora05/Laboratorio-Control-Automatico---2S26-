/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: PID_Arduino.c
 *
 * Code generated for Simulink model 'PID_Arduino'.
 *
 * Model version                  : 1.8
 * Simulink Coder version         : 26.1 (R2026a) 20-Nov-2025
 * C/C++ source code generated on : Wed Oct 14 14:07:55 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "PID_Arduino.h"
#include "rtwtypes.h"
#include "PID_Arduino_private.h"

P_PID_Arduino_T PID_Arduino_P = {
  /* Mask Parameter: PIDController_D
   * Referenced by: '<S31>/Derivative Gain'
   */
  48.0,

  /* Mask Parameter: PIDController_I
   * Referenced by: '<S35>/Integral Gain'
   */
  0.000633,

  /* Mask Parameter: PIDController_InitialConditionF
   * Referenced by: '<S33>/Filter'
   */
  0.0,

  /* Mask Parameter: PIDController_InitialConditio_j
   * Referenced by: '<S38>/Integrator'
   */
  0.0,

  /* Mask Parameter: PIDController_LowerSaturationLi
   * Referenced by:
   *   '<S45>/Saturation'
   *   '<S30>/DeadZone'
   */
  0.0,

  /* Mask Parameter: PIDController_N
   * Referenced by: '<S41>/Filter Coefficient'
   */
  100.0,

  /* Mask Parameter: PIDController_P
   * Referenced by: '<S43>/Proportional Gain'
   */
  0.395,

  /* Mask Parameter: PIDController_UpperSaturationLi
   * Referenced by:
   *   '<S45>/Saturation'
   *   '<S30>/DeadZone'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S28>/Constant1'
   */
  0.0,

  /* Expression: 45
   * Referenced by: '<Root>/Constant2'
   */
  45.0,

  /* Computed Parameter: Integrator_gainval
   * Referenced by: '<S38>/Integrator'
   */
  1.0,

  /* Computed Parameter: Filter_gainval
   * Referenced by: '<S33>/Filter'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S28>/Clamping_zero'
   */
  0.0,

  /* Computed Parameter: Constant_Value
   * Referenced by: '<S28>/Constant'
   */
  1,

  /* Computed Parameter: Constant2_Value_c
   * Referenced by: '<S28>/Constant2'
   */
  -1,

  /* Computed Parameter: Constant3_Value
   * Referenced by: '<S28>/Constant3'
   */
  1,

  /* Computed Parameter: Constant4_Value
   * Referenced by: '<S28>/Constant4'
   */
  -1
};

/* System initialize for referenced model: 'PID_Arduino' */
void PID_Arduino_Init(DW_PID_Arduino_f_T *localDW)
{
  /* InitializeConditions for DiscreteIntegrator: '<S38>/Integrator' */
  localDW->Integrator_DSTATE = PID_Arduino_P.PIDController_InitialConditio_j;

  /* InitializeConditions for DiscreteIntegrator: '<S33>/Filter' */
  localDW->Filter_DSTATE = PID_Arduino_P.PIDController_InitialConditionF;
}

/* Output and update for referenced model: 'PID_Arduino' */
void PID_ArduinoTID0(void)
{
}

/* Output and update for referenced model: 'PID_Arduino' */
void PID_ArduinoTID1(const real32_T *rtu_In1, real_T *rty_Out1,
                     DW_PID_Arduino_f_T *localDW)
{
  real_T rtb_DeadZone;
  real_T rtb_FilterCoefficient;
  real_T rtb_IntegralGain;
  real_T rtb_Sum;
  int8_T tmp;
  int8_T tmp_0;

  /* Sum: '<Root>/Sum4' incorporates:
   *  Constant: '<Root>/Constant2'
   */
  rtb_IntegralGain = PID_Arduino_P.Constant2_Value - *rtu_In1;

  /* Gain: '<S41>/Filter Coefficient' incorporates:
   *  DiscreteIntegrator: '<S33>/Filter'
   *  Gain: '<S31>/Derivative Gain'
   *  Sum: '<S33>/SumD'
   */
  rtb_FilterCoefficient = (PID_Arduino_P.PIDController_D * rtb_IntegralGain -
    localDW->Filter_DSTATE) * PID_Arduino_P.PIDController_N;

  /* Sum: '<S47>/Sum' incorporates:
   *  DiscreteIntegrator: '<S38>/Integrator'
   *  Gain: '<S43>/Proportional Gain'
   */
  rtb_Sum = (PID_Arduino_P.PIDController_P * rtb_IntegralGain +
             localDW->Integrator_DSTATE) + rtb_FilterCoefficient;

  /* DeadZone: '<S30>/DeadZone' incorporates:
   *  Saturate: '<S45>/Saturation'
   */
  if (rtb_Sum > PID_Arduino_P.PIDController_UpperSaturationLi) {
    rtb_DeadZone = rtb_Sum - PID_Arduino_P.PIDController_UpperSaturationLi;
    *rty_Out1 = PID_Arduino_P.PIDController_UpperSaturationLi;
  } else {
    if (rtb_Sum >= PID_Arduino_P.PIDController_LowerSaturationLi) {
      rtb_DeadZone = 0.0;
    } else {
      rtb_DeadZone = rtb_Sum - PID_Arduino_P.PIDController_LowerSaturationLi;
    }

    if (rtb_Sum < PID_Arduino_P.PIDController_LowerSaturationLi) {
      *rty_Out1 = PID_Arduino_P.PIDController_LowerSaturationLi;
    } else {
      *rty_Out1 = rtb_Sum;
    }
  }

  /* End of DeadZone: '<S30>/DeadZone' */

  /* Gain: '<S35>/Integral Gain' */
  rtb_IntegralGain *= PID_Arduino_P.PIDController_I;

  /* Switch: '<S28>/Switch1' incorporates:
   *  Constant: '<S28>/Clamping_zero'
   *  Constant: '<S28>/Constant'
   *  Constant: '<S28>/Constant2'
   *  RelationalOperator: '<S28>/fix for DT propagation issue'
   */
  if (rtb_DeadZone > PID_Arduino_P.Clamping_zero_Value) {
    tmp = PID_Arduino_P.Constant_Value;
  } else {
    tmp = PID_Arduino_P.Constant2_Value_c;
  }

  /* Switch: '<S28>/Switch2' incorporates:
   *  Constant: '<S28>/Clamping_zero'
   *  Constant: '<S28>/Constant3'
   *  Constant: '<S28>/Constant4'
   *  RelationalOperator: '<S28>/fix for DT propagation issue1'
   */
  if (rtb_IntegralGain > PID_Arduino_P.Clamping_zero_Value) {
    tmp_0 = PID_Arduino_P.Constant3_Value;
  } else {
    tmp_0 = PID_Arduino_P.Constant4_Value;
  }

  /* Switch: '<S28>/Switch' incorporates:
   *  Constant: '<S28>/Clamping_zero'
   *  Constant: '<S28>/Constant1'
   *  Logic: '<S28>/AND3'
   *  RelationalOperator: '<S28>/Equal1'
   *  RelationalOperator: '<S28>/Relational Operator'
   *  Switch: '<S28>/Switch1'
   *  Switch: '<S28>/Switch2'
   */
  if ((PID_Arduino_P.Clamping_zero_Value != rtb_DeadZone) && (tmp == tmp_0)) {
    rtb_IntegralGain = PID_Arduino_P.Constant1_Value;
  }

  /* Update for DiscreteIntegrator: '<S38>/Integrator' incorporates:
   *  Switch: '<S28>/Switch'
   */
  localDW->Integrator_DSTATE += PID_Arduino_P.Integrator_gainval *
    rtb_IntegralGain;

  /* Update for DiscreteIntegrator: '<S33>/Filter' */
  localDW->Filter_DSTATE += PID_Arduino_P.Filter_gainval * rtb_FilterCoefficient;
}

/* Model initialize function */
void PID_Arduino_initialize(const char_T **rt_errorStatus,
  RT_MODEL_PID_Arduino_T *const PID_Arduino_M)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatusPointer(PID_Arduino_M, rt_errorStatus);
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
